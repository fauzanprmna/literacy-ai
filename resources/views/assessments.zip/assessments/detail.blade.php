@extends(Auth::user()->role === 'admin' ? 'template.template-admin' : 'template.template-mahasiswa')

@section('title', 'Detail Asesmen')
@section('header', 'Detail Asesmen')

@push('head')
    <style>
        .detail-board {
            display: grid;
            gap: 24px;
        }

        .detail-header,
        .detail-summary,
        .detail-dimensions,
        .detail-questions {
            background: var(--white);
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 24px;
        }

        .detail-top {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 18px;
        }

        .detail-title {
            font-size: 22px;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 6px;
        }

        .detail-meta {
            display: grid;
            gap: 8px;
        }

        .detail-meta-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-600);
            font-size: 13px;
        }

        .detail-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
        }

        .summary-card {
            background: var(--green-50);
            border-radius: var(--radius-md);
            padding: 18px;
            display: grid;
            gap: 6px;
        }

        .summary-card .summary-label {
            font-size: 12px;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: .08em;
            font-weight: 700;
        }

        .summary-card .summary-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--green-700);
        }

        .summary-card .summary-badge {
            display: inline-flex;
            padding: 6px 14px;
            border-radius: 999px;
            background: var(--green-600);
            color: var(--white);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .detail-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            flex-wrap: wrap;
        }

        .detail-actions a,
        .detail-actions button {
            display: inline-flex;
            gap: 8px;
            align-items: center;
            border-radius: var(--radius-sm);
            padding: 10px 16px;
            border: 1px solid var(--gray-200);
            background: var(--white);
            color: var(--gray-800);
            text-decoration: none;
            font-weight: 700;
            cursor: pointer;
            transition: background .2s ease, border-color .2s ease;
        }

        .detail-actions a:hover,
        .detail-actions button:hover {
            border-color: var(--green-600);
            background: var(--green-50);
        }

        .detail-actions .btn-primary {
            background: var(--green-600);
            color: var(--white);
            border-color: transparent;
        }

        .detail-actions .btn-primary:hover {
            background: var(--green-700);
        }

        .dimension-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .dimension-card {
            background: var(--green-50);
            border-radius: var(--radius-md);
            padding: 18px;
            border: 1px solid var(--gray-100);
        }

        .dimension-slider-section {
            padding: 0 0 18px;
        }

        .slider-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
        }

        .slider-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--gray-800);
        }

        .slider-controls {
            display: flex;
            gap: 8px;
        }

        .slider-btn {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            border: 1px solid var(--gray-200);
            background: var(--white);
            color: var(--gray-600);
            display: grid;
            place-items: center;
            cursor: pointer;
            transition: all .2s ease;
        }

        .slider-btn:hover {
            background: var(--green-50);
            border-color: var(--green-100);
            color: var(--green-700);
        }

        .dimension-slider {
            display: grid;
            grid-auto-flow: column;
            grid-auto-columns: minmax(260px, 1fr);
            gap: 16px;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            padding-bottom: 8px;
        }

        .dimension-slider::-webkit-scrollbar {
            height: 8px;
        }

        .dimension-slider::-webkit-scrollbar-thumb {
            background: rgba(36, 59, 48, .35);
            border-radius: 999px;
        }

        .dimension-slide {
            scroll-snap-align: start;
        }

        .dimension-name {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--gray-600);
            margin-bottom: 10px;
        }

        .dimension-score {
            font-size: 22px;
            font-weight: 800;
            color: var(--green-700);
        }

        .progress-bar {
            margin-top: 14px;
            height: 10px;
            border-radius: 999px;
            background: var(--gray-200);
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            border-radius: 999px;
            background: linear-gradient(90deg, #0d2b1f 0%, #2a9468 100%);
        }

        .progress-meta {
            margin-top: 10px;
            font-size: 13px;
            color: var(--gray-600);
        }

        .question-group {
            background: var(--white);
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            padding: 22px;
            margin-bottom: 18px;
        }

        .dimension-group-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            font-size: 16px;
            font-weight: 700;
            color: var(--gray-800);
        }

        .question-group-grid {
            display: grid;
            gap: 18px;
        }

        .question-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 18px;
        }

        .question-card {
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            padding: 20px;
            background: var(--gray-50);
            display: grid;
            gap: 14px;
        }

        .question-info {
            display: grid;
            gap: 8px;
        }

        .question-meta {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: var(--gray-600);
        }

        .status-pill {
            display: inline-flex;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .status-correct {
            background: #dcfce7;
            color: #166534;
        }

        .status-wrong {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-likert {
            background: #d1fae5;
            color: #0f766e;
        }

        .answer-label {
            font-size: 12px;
            font-weight: 700;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: .08em;
            margin-bottom: 6px;
            display: block;
        }

        .answer-value {
            font-size: 14px;
            color: var(--gray-800);
            line-height: 1.6;
        }


        .question-header {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 12px;
            align-items: baseline;
        }

        .question-number {
            color: var(--green-700);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .08em;
        }

        .question-text {
            font-size: 15px;
            font-weight: 600;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .answer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
        }

        .answer-card {
            padding: 16px;
            border-radius: var(--radius-md);
            background: var(--white);
            border: 1px solid var(--gray-200);
        }

        .answer-label {
            font-size: 11px;
            font-weight: 700;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: .08em;
            margin-bottom: 8px;
            display: block;
        }

        .answer-value {
            font-size: 14px;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .status-label {
            display: inline-flex;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .status-correct {
            color: var(--green-700);
            background: #dcfce7;
        }

        .status-wrong {
            color: var(--red);
            background: #fee2e2;
        }

        @media (max-width: 768px) {

            .detail-top,
            .detail-actions,
            .detail-summary-grid,
            .dimension-grid,
            .answer-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
@endpush

@section('content')
    <div class="detail-board">
        <div class="detail-header">
            <div class="detail-top">
                <div>
                    <h2 class="detail-title">{{ __('assessment.assessment_result') }}</h2>
                    <div class="detail-meta">
                        <span class="detail-meta-item"><i class="bi bi-calendar3"></i>
                            {{ $sessionDate->locale(app()->getLocale())->translatedFormat('d F Y, H:i') }} WIB</span>
                        <span class="detail-meta-item"><i class="bi bi-clock"></i> {{ $duration ?? '-' }}</span>
                        <span class="detail-meta-item"><i class="bi bi-check2-circle"></i>
                            {{ $totalQuestions > 0 ? 'Selesai' : 'Belum lengkap' }}</span>
                    </div>
                </div>
                <div class="detail-actions">
                    <a href="{{ route('assessments.history') }}">
                        <i class="bi bi-arrow-left"></i>
                        {{ __('messages.back') }}
                    </a>
                    <a href="{{ route('assessments.history.export.session', $sessionKey) }}" class="btn-primary">
                        <i class="bi bi-download"></i>
                        {{ __('assessment.export_pdf') }}
                    </a>
                </div>
            </div>
        </div>

        <div class="detail-summary">
            <div class="detail-summary-grid">
                <div class="summary-card">
                    <div class="summary-label">{{ __('assessment.total_score') }}</div>
                    <div class="summary-value">{{ $overallScore }}%</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">{{ __('messages.category') }}</div>
                    <div class="summary-value">{{ $instrumentScore }}</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">{{ __('assessment.total_questions') }}</div>
                    <div class="summary-value">{{ $totalQuestions }}</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">{{ __('assessment.correct_answers') }}</div>
                    <div class="summary-value">{{ $correctAnswers }}</div>
                </div>
            </div>
        </div>

        <div class="detail-dimensions dimension-slider-section">
            <div class="slider-header">
                <div class="slider-title">{{ __('assessment.score_per_dimension') }}</div>
                <div class="slider-controls">
                    <button type="button" class="slider-btn" id="sliderPrev" aria-label="Previous dimension">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                    <button type="button" class="slider-btn" id="sliderNext" aria-label="Next dimension">
                        <i class="bi bi-chevron-right"></i>
                    </button>
                </div>
            </div>

            <div class="dimension-slider" id="dimensionSlider">
                @foreach ($responsesByDimension as $dimension => $data)
                    <div class="dimension-slide">
                        <div class="dimension-card">
                            <div class="dimension-name">{{ $dimension }}</div>
                            <div class="dimension-score">{{ $data['score'] }}%</div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: {{ $data['score'] }}%;"></div>
                            </div>
                            <div class="progress-meta">{{ __('assessment.correct') }} {{ $data['correct'] }}
                                {{ __('assessment.from') }} {{ $data['total'] }} {{ __('assessment.questions') }}</div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <div class="detail-questions">
            <div class="question-group">
                <div class="dimension-group-header">{{ __('assessment.question_details') }}</div>

                @php
                    $questionsByDimension = $responses->groupBy(
                        fn($response) => $response->question->dimension ?? 'Umum',
                    );
                @endphp

                <div class="question-group-grid">
                    @foreach ($questionsByDimension as $dimension => $group)
                        <div class="question-group">
                            <div class="dimension-group-header">
                                <span>{{ $dimension }}</span>
                                <span>{{ $group->count() }} soal</span>
                            </div>

                            <div class="question-grid">
                                @foreach ($group as $index => $response)
                                    @php
                                        $questionText =
                                            $response->question->translation->question ?? $response->question->question;
                                        $isLikert = $response->question->type === 'likert';
                                        $isCorrect = !$isLikert && $response->answer_bobot > 0;
                                        $statusClass = $isLikert
                                            ? 'status-likert'
                                            : ($isCorrect
                                                ? 'status-correct'
                                                : 'status-wrong');
                                        $statusLabel = $isLikert
                                            ? sprintf('Skor %s', $response->answer_bobot)
                                            : ($isCorrect
                                                ? 'Benar'
                                                : 'Salah');
                                    @endphp
                                    <div class="question-card">
                                        <div class="question-info">
                                            <div class="question-meta">
                                                <span class="question-number">Soal {{ $index + 1 }}</span>
                                                <span class="status-pill {{ $statusClass }}">{{ $statusLabel }}</span>
                                            </div>
                                            <div class="question-text">{{ $questionText }}</div>
                                        </div>

                                        <div>
                                            <span class="answer-label">{{ __('assessment.answer_bobot') }}</span>
                                            <div class="answer-value">
                                                {{ $response->answer_bobot }}
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            const dimensionSlider = document.getElementById('dimensionSlider');
            const sliderPrev = document.getElementById('sliderPrev');
            const sliderNext = document.getElementById('sliderNext');

            sliderPrev?.addEventListener('click', () => {
                if (!dimensionSlider) return;
                dimensionSlider.scrollBy({
                    left: -280,
                    behavior: 'smooth'
                });
            });

            sliderNext?.addEventListener('click', () => {
                if (!dimensionSlider) return;
                dimensionSlider.scrollBy({
                    left: 280,
                    behavior: 'smooth'
                });
            });
        </script>
    @endpush
@endsection
