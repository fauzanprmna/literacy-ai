@extends(Auth::user()->role === 'admin' ? 'template.template-admin' : 'template.template-mahasiswa')

@section('title', 'Riwayat Asesmen')
@section('header', 'Riwayat Asesmen')

@push('head')
    <style>
        .history-board {
            display: grid;
            gap: 24px;
        }

        .history-summary,
        .history-controls,
        .history-list,
        .history-empty {
            background: var(--white);
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 24px;
        }

        .history-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
        }

        .history-stat {
            background: var(--green-50);
            border-radius: var(--radius-md);
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .history-stat .stat-label {
            font-size: 12px;
            text-transform: uppercase;
            color: var(--gray-500);
            letter-spacing: .06em;
            font-weight: 700;
        }

        .history-stat .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--green-700);
        }

        .history-controls {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            align-items: center;
            justify-content: space-between;
        }

        .history-controls form {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
        }

        .history-controls .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 180px;
        }

        .history-controls label {
            font-size: 12px;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: .08em;
            font-weight: 700;
        }

        .history-controls select,
        .history-controls button {
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-sm);
            padding: 10px 14px;
            font-size: 14px;
            color: var(--gray-800);
            background: var(--white);
        }

        .history-controls button {
            cursor: pointer;
            font-weight: 700;
            background: var(--green-600);
            color: var(--white);
            border-color: transparent;
            transition: background .2s ease;
        }

        .history-controls button:hover {
            background: var(--green-700);
        }

        .history-item {
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
            padding: 20px;
            display: grid;
            gap: 18px;
            transition: transform .18s ease, box-shadow .18s ease;
        }

        .history-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .history-header {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 16px;
            align-items: start;
        }

        .history-meta {
            display: grid;
            gap: 10px;
        }

        .history-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .history-label {
            font-size: 13px;
            color: var(--gray-500);
            min-width: 110px;
        }

        .history-value {
            font-size: 14px;
            font-weight: 700;
            color: var(--gray-800);
        }

        .history-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            color: var(--white);
            background: var(--green-600);
        }

        .history-score {
            display: grid;
            gap: 6px;
            text-align: right;
        }

        .history-score .score-number {
            font-size: 42px;
            font-weight: 800;
            color: var(--green-700);
            line-height: 1;
        }

        .history-score .score-label {
            font-size: 12px;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: .08em;
            font-weight: 700;
        }

        .history-dimensions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 12px;
        }

        .dimension-pill {
            background: var(--green-50);
            border-radius: var(--radius-sm);
            padding: 12px 14px;
            border: 1px solid var(--gray-100);
            display: grid;
            gap: 4px;
        }

        .dimension-pill .dimension-name {
            font-size: 12px;
            color: var(--gray-600);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
        }

        .dimension-pill .dimension-value {
            font-size: 16px;
            font-weight: 700;
            color: var(--green-700);
        }

        .history-action {
            display: flex;
            justify-content: flex-end;
        }

        .history-action a {
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: var(--radius-sm);
            background: var(--green-600);
            color: var(--white);
            font-size: 14px;
            font-weight: 700;
            transition: background .2s ease;
        }

        .history-action a:hover {
            background: var(--green-700);
        }

        .empty-state {
            text-align: center;
            padding: 48px 24px;
        }

        .empty-state h3 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .empty-state p {
            color: var(--gray-600);
            margin-bottom: 18px;
        }

        .empty-state a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: var(--radius-sm);
            background: var(--green-600);
            color: var(--white);
            text-decoration: none;
            font-weight: 700;
        }

        @media (max-width: 768px) {

            .history-header,
            .history-score {
                text-align: left;
            }

            .history-action {
                justify-content: flex-start;
            }
        }
    </style>
@endpush

@section('content')
    <div class="history-board">
        <div class="history-summary">
            <div class="history-summary-grid">
                <div class="history-stat">
                    <div class="stat-label">Total Asesmen</div>
                    <div class="stat-value">{{ $totalAssessments }}</div>
                </div>
                <div class="history-stat">
                    <div class="stat-label">Rata-rata Skor</div>
                    <div class="stat-value">{{ $averageScore }}%</div>
                </div>
                <div class="history-stat">
                    <div class="stat-label">Filter saat ini</div>
                    <div class="stat-value">{{ ucfirst(request('sort', 'terbaru')) }} /
                        {{ ucfirst(request('status', 'semua')) }}</div>
                </div>
            </div>
        </div>

        <div class="history-controls">
            <form method="GET" action="{{ route('assessments.history') }}">
                <div class="filter-group">
                    <label for="sort">Urutkan</label>
                    <select id="sort" name="sort" onchange="this.form.submit()">
                        <option value="terbaru" {{ request('sort', 'terbaru') === 'terbaru' ? 'selected' : '' }}>Terbaru
                        </option>
                        <option value="tertua" {{ request('sort') === 'tertua' ? 'selected' : '' }}>Tertua</option>
                        <option value="skor-tinggi" {{ request('sort') === 'skor-tinggi' ? 'selected' : '' }}>Skor Tertinggi
                        </option>
                        <option value="skor-rendah" {{ request('sort') === 'skor-rendah' ? 'selected' : '' }}>Skor Terendah
                        </option>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" onchange="this.form.submit()">
                        <option value="semua" {{ request('status', 'semua') === 'semua' ? 'selected' : '' }}>Semua Status
                        </option>
                        <option value="selesai" {{ request('status') === 'selesai' ? 'selected' : '' }}>Selesai</option>
                        <option value="belum" {{ request('status') === 'belum' ? 'selected' : '' }}>Belum Dinilai</option>
                    </select>
                </div>
            </form>

            <a href="{{ route('assessments.history.export') }}" class="btn-export">
                <i class="bi bi-download"></i>
                Export PDF
            </a>
        </div>

        @forelse($assessments as $assessment)
            <article class="history-item">
                <div class="history-header">
                    <div class="history-meta">
                        <div class="history-row">
                            <span class="history-label">Tanggal</span>
                            <span
                                class="history-value">{{ $assessment['date']->locale(app()->getLocale())->translatedFormat('d F Y') }}</span>
                        </div>
                        <div class="history-row">
                            <span class="history-label">Waktu</span>
                            <span class="history-value">{{ $assessment['date']->format('H:i') }} WIB</span>
                        </div>
                        <div class="history-row">
                            <span class="history-label">Durasi</span>
                            <span class="history-value">{{ $assessment['duration'] ?? '-' }}</span>
                        </div>
                        <div class="history-row">
                            <span class="history-label">Soal</span>
                            <span class="history-value">{{ $assessment['total_questions'] }} pertanyaan</span>
                        </div>
                        <div class="history-row">
                            <span class="history-label">Status</span>
                            <span
                                class="history-badge">{{ $assessment['total_questions'] > 0 ? 'Selesai' : 'Belum' }}</span>
                        </div>
                    </div>

                    <div class="history-score">
                        <div class="score-number">{{ $assessment['score'] }}</div>
                        <div class="score-label">Nilai</div>
                        <div class="history-badge">{{ $assessment['category'] }}</div>
                    </div>
                </div>

                @if (count($assessment['dimension_scores']) > 0)
                    <div class="history-dimensions">
                        @foreach ($assessment['dimension_scores'] as $dimension => $score)
                            <div class="dimension-pill">
                                <div class="dimension-name">{{ $dimension }}</div>
                                <div class="dimension-value">{{ $score }}%</div>
                            </div>
                        @endforeach
                    </div>
                @endif

                <div class="history-action">
                    <a href="{{ route('assessments.detail', $assessment['session_key']) }}">
                        <i class="bi bi-eye"></i>
                        Lihat Detail
                    </a>
                </div>
            </article>
        @empty
            <div class="history-empty empty-state">
                <h3>Belum ada riwayat asesmen</h3>
                <p>Mulai pengukuran literasi AI Anda sekarang untuk melihat hasil dan riwayat asesmen.</p>
                <a href="{{ route('pengukuran.index') }}">
                    <i class="bi bi-play-fill"></i>
                    Mulai Pengukuran
                </a>
            </div>
        @endforelse
    </div>
@endsection
