<?php

return [
    // ── Welcome card ──
    'system_summary'         => 'System Summary',
    'total_system_data'      => 'Total System Data',

    // ── Stats grid ──
    'total_users'            => 'Total Users',
    'total_modules'          => 'Total Modules',
    'students_assessed'      => 'Students Who Took Assessment',
    'lecturers_assessed'     => 'Lecturers Who Took Assessment',
    'total_answers'          => 'Total Answers',
    'active_users'           => 'Active Users',

    // ── Summary card ──
    'all_results_summary'    => 'All Assessment Results Summary',
    'average_score'          => 'Average Score',
    'highest_score'          => 'Highest Score',
    'lowest_score'           => 'Lowest Score',
    'total_questions'        => 'Total Questions',

    // ── Charts ──
    'score_distribution'     => 'Score Distribution',
    'user_score_category'    => 'User Score Categories',
    'score_per_category'     => 'Score per Category',

    // ── Category metrics ──
    'category_summary'       => 'Score Category Summary',
    'high_score_label'       => 'High Score (≥70)',
    'medium_score_label'     => 'Medium Score (50–69)',
    'low_score_label'        => 'Low Score (<50)',
    'percent_of_total'       => '% of total users',

    // ── Per-category analysis ──
    'detail_per_category'    => 'Detailed Analysis per Category',
    'correct_from_total'     => ':correct / :total correct',
    'no_category'            => 'No categories yet',

    // ── Recent assessments table ──
    'recent_assessments'     => 'Recent Assessments (Last 10)',
    'user_header'            => 'User',
    'datetime_header'        => 'Date & Time',
    'total_questions_header' => 'Total Questions',
    'correct_answers_header' => 'Correct Answers',
    'score_header'           => 'Score',
    'category_header'        => 'Category',
    'high_category'          => 'High',
    'medium_category'        => 'Medium',
    'low_category'           => 'Low',
    'no_assessment_data'     => 'No assessment data yet',

    // ── Quick links ──
    'quick_links'            => 'Quick Links',
    'add_user'               => 'Add User',
    'add_module'             => 'Add Module',
    'answer_template'        => 'Answer Template',
    'questions_menu'         => 'Questions',
    'category_menu'          => 'Category',
    'view_all_results'       => 'View All Results',
];
